#install.packages("gtable")

#install.packages(c("ggplot2", "moments"))
#install.packages("ggplot2", dependencies = TRUE)
#library(ggplot2)

###configurar el directorio de trabajo
setwd("H:/UNIR/Analisis/Tema5")#las barras de directorio son las inclinadas hacia la derecha distinto de windows

getwd()#confirmar el directorio actual

"1.	Análisis de Datos de Salud:
o	Tenemos un dataset con información sobre pacientes, incluyendo variables como fumador (Sí/No), edad, y enfermedad 
respiratoria (Sí/No). Calcula la probabilidad de que un paciente tenga una enfermedad respiratoria si ya se sabe que es fumador.
¿Para qué sirve?: Este tipo de análisis es fundamental en la epidemiología y permite a los analistas de datos y profesionales de 
la salud identificar factores de riesgo. Entender cómo el tabaquismo influye en la probabilidad de contraer enfermedades permite 
planificar intervenciones médicas adecuadas."

# Dataset simulado
Fumador <- c('Sí', 'No', 'Sí', 'No', 'Sí', 'No', 'Sí', 'No', 'Sí')
EnfermedadRespiratoria <- c('Sí', 'No', 'Sí', 'No', 'No', 'No', 'Sí', 'No', 'No')

# Crear dataframe
df <- data.frame(Fumador, EnfermedadRespiratoria)

# Calcular probabilidad condicional
fumadores <- df[df$Fumador == 'Sí', ]
probabilidad_condicional <- nrow(fumadores[fumadores$EnfermedadRespiratoria == 'Sí', ]) / nrow(fumadores)

cat("Probabilidad de enfermedad respiratoria dado que es fumador:", probabilidad_condicional)

