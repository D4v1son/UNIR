#install.packages("gtable")

#install.packages(c("ggplot2", "moments"))
#install.packages("ggplot2", dependencies = TRUE)
#library(ggplot2)


"En una universidad, el 60% de los estudiantes son mujeres, y el 40% estudia ingeniería. Del total, 
el 25% son mujeres que estudian ingeniería. ¿Cuál es la probabilidad de que un estudiante sea mujer 
dado que estudia ingeniería?"

# Probabilidades dadas
P_Mujer <- 0.6
P_Ingenieria <- 0.4
P_Mujer_Ingenieria <- 0.25

# Probabilidad condicional
P_Mujer_given_Ingenieria <- P_Mujer_Ingenieria / P_Ingenieria

cat("Probabilidad de ser mujer dado que estudia ingeniería:", P_Mujer_given_Ingenieria, "\n")
