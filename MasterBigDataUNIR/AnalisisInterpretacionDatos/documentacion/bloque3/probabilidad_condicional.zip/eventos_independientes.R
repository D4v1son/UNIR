#install.packages("gtable")

#install.packages(c("ggplot2", "moments"))
#install.packages("ggplot2", dependencies = TRUE)
#library(ggplot2)


# Simulación
set.seed(123)
moneda <- sample(c("Cara", "Cruz"), size = 1000, replace = TRUE)
dado <- sample(1:6, size = 1000, replace = TRUE)

# Frecuencias conjuntas
tabla_conjunta <- table(moneda, dado)
tabla_probabilidades <- prop.table(tabla_conjunta)

# Probabilidades individuales
P_Cara <- sum(tabla_probabilidades["Cara", ])
P_6 <- sum(tabla_probabilidades[, "6"])
P_Cara_y_6 <- tabla_probabilidades["Cara", "6"]

# Independencia: P(A ∩ B) == P(A) * P(B)
es_independiente <- abs(P_Cara_y_6 - (P_Cara * P_6)) < 1e-6

cat("Probabilidad de Cara y 6:", P_Cara_y_6, "\n")
cat("Probabilidad de Cara:", P_Cara, "\n")
cat("Probabilidad de 6:", P_6, "\n")
cat("¿Son independientes?:", es_independiente, "\n")
