#install.packages("gtable")

#install.packages(c("ggplot2", "moments"))
#install.packages("ggplot2", dependencies = TRUE)
#library(ggplot2)

###configurar el directorio de trabajo


# Simulación de lanzamiento de una moneda
set.seed(123) # Para reproducibilidad
lanzamientos <- sample(c("Cara", "Cruz"), size = 10, replace = TRUE)

# Calcular frecuencias
tabla_frecuencias <- table(lanzamientos)
probabilidad_cara <- tabla_frecuencias["Cara"] / sum(tabla_frecuencias)

cat("Lanzamientos:", lanzamientos, "\n")
cat("Probabilidad de obtener Cara:", probabilidad_cara, "\n")
