# Configuración de la ventana gráfica
par(mfrow = c(1, 2)) # Divide la ventana gráfica en 1 fila y 2 columnas

# Modelo Discreto: Distribución Binomial
n <- 5  # Número de ensayos
p <- 0.4  # Probabilidad de éxito
x <- 0:n  # Valores posibles de X
pmf <- dbinom(x, n, p)  # Función de masa de probabilidad

# Gráfica del modelo binomial
plot(x, pmf, type = "h", lwd = 2, col = "blue", xlab = "Número de Fallos", 
     ylab = "Probabilidad", main = "Modelo Discreto: Binomial B(5, 0.4)")
points(x, pmf, pch = 16, col = "red")
grid()

# Modelo Continuo: Distribución Normal
mu <- 30  # Media
sigma <- 5  # Desviación estándar
x_norm <- seq(mu - 4 * sigma, mu + 4 * sigma, length = 1000)  # Rango de valores
pdf_norm <- dnorm(x_norm, mean = mu, sd = sigma)  # Función de densidad de probabilidad

# Gráfica del modelo normal
plot(x_norm, pdf_norm, type = "l", lwd = 2, col = "blue", xlab = "Tiempo de Reinicio (minutos)", 
     ylab = "Densidad de Probabilidad", main = "Modelo Continuo: Normal N(30, 5^2)")
polygon(c(25, seq(25, 35, length = 500), 35), 
        c(0, dnorm(seq(25, 35, length = 500), mean = mu, sd = sigma), 0), 
        col = "orange", border = NA) # Área entre 25 y 35
abline(v = mu, col = "red", lty = 2)  # Línea vertical en la media
grid()

"    Gráfica Binomial:
        Utiliza dbinom para calcular las probabilidades.
        Representa la distribución como un diagrama de barras (type = "h").
        Añade puntos rojos en las probabilidades con points().

    Gráfica Normal:
        Calcula la función de densidad con dnorm.
        Usa polygon() para sombrear el área bajo la curva entre 25 y 35 minutos.
        Añade una línea vertical punteada en la media (μ=30μ=30).

Resultado:

    Gráfica 1 (Binomial): Muestra la probabilidad de obtener 0 a 5 fallos diarios.
    Gráfica 2 (Normal): Representa la densidad de probabilidad y el área sombreada entre 25 y 35 minutos."